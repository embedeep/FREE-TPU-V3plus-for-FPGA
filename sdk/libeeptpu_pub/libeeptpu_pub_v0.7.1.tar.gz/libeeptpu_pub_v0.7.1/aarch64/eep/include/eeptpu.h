#ifndef _EEPTPU_H
#define _EEPTPU_H

#include <vector>
#include <string>

enum {
    eepInterfaceType_NONE  = 0,
    eepInterfaceType_SOC   = 1,
    eepInterfaceType_PCIE,
    eepInterfaceType_EOF,  /* dummy data. */
};

// 推理结果
struct EEPTPU_RESULT
{
    float* data;
    int shape[4];
};

enum {
    idxPar  = 0,
    idxIn,
    idxTmp,
    idxOut,
    idxAlg,
};

struct NET_MEM_ADDR
{
    unsigned long par;
    unsigned long alg;
    unsigned long in;
    unsigned long out;
    unsigned long tmp;
    NET_MEM_ADDR(): par(0), alg(0), in(0), out(0), tmp(0) { }
};

struct NET_MEM_SIZE
{
    unsigned int par;
    unsigned int alg;
    unsigned int in;
    unsigned int out;
    unsigned int tmp;
    NET_MEM_SIZE(): par(0), alg(0), in(0), out(0), tmp(0) { }
};

// set TPUs register zones
struct EEPTPU_REG_ZONE
{
    int core_id;            // core id
    // PCIE mode with multi-cores, set the same global base addr for these cores and use offset for each core.
    // SOC mode, could set each zone with different base address in 'addr', and offset=0.
    unsigned long addr;      // register zone base addr. 
    unsigned int offset;    // current core register zone offset from global base addr
    unsigned int size;      // current core register zone size
    EEPTPU_REG_ZONE(): core_id(0), addr(0), offset(0), size(0) { }
};

enum eepDataType
{
    DType_None   = 0,
    DType_FP32   = 1,
    DType_FP16   = 2,
    DType_INT8   = 3,
    DType_INT16  = 4,
    DType_INT32  = 5,
    DType_EF16   = 6,
    DType_UINT8  = 7,
};

struct NET_INPUT_INFO
{
    int input_id;
    int c;
    int h;
    int w;
    std::string name;
    std::vector<float> mean;
    std::vector<float> norm;
    int pack_type;    // =0: not use pack mode; >0: use pack
    int pack_out_c;
    int pack_out_h;
    int pack_out_w;
    
    NET_INPUT_INFO(): 
        input_id(0), c(0), h(0), w(0), name(""),
        pack_type(0), pack_out_c(0), pack_out_h(0), pack_out_w(0) 
    { }
};

class EEPTPU 
{
public:
    EEPTPU* init();
    EEPTPU();
    virtual ~EEPTPU();
    
    virtual int eeptpu_set_interface(int interface_type) = 0;
    virtual int eeptpu_set_interface_info_pcie(const char* dev_reg, const char* dev_h2c, const char* dev_c2h) = 0;
    
    virtual int eeptpu_set_tpu_mem_base_addr(unsigned long mem_base_addr) = 0;
    virtual int eeptpu_set_tpu_reg_zones(std::vector<struct EEPTPU_REG_ZONE>& regzones) = 0;
  
    virtual int eeptpu_set_base_address(unsigned long base0, unsigned long base1) = 0;
    virtual int eeptpu_set_base_address(unsigned long base_par, unsigned long base_in, unsigned long base_out, unsigned long base_tmp) = 0;
    
    virtual int eeptpu_load_bin(const char* path_bin, int fg_multi=0) = 0;
    virtual int eeptpu_jump_update(EEPTPU* alg2) = 0;

    virtual int eeptpu_set_input(void* input_data, int dim1, int dim2, int dim3, int mode = 0, int data_type = DType_FP32) = 0;
    virtual int eeptpu_set_input(int input_id, void* input_data, int dim1, int dim2, int dim3, int mode = 0, int data_type = DType_FP32) = 0;
    virtual int eeptpu_get_input_info(std::vector<struct NET_INPUT_INFO>& input_info) = 0;
    virtual void eeptpu_get_mean_norm(std::vector<float>& get_mean, std::vector<float>& get_norm) = 0;
    virtual int eeptpu_wait_input_writable(unsigned int timeout_ms = 2000) = 0;

    virtual int eeptpu_set_forward_timeout(unsigned int ms) = 0;
    virtual int eeptpu_forward(std::vector<struct EEPTPU_RESULT>& result) = 0;
    virtual unsigned int eeptpu_get_tpu_forward_time() = 0;

    virtual void eeptpu_terminate(bool b_term) = 0;
    virtual void eeptpu_close() = 0;    

    virtual char* eeptpu_get_lib_version() = 0;
    virtual char* eeptpu_get_tpu_version() = 0;
    virtual char* eeptpu_get_tpu_info() = 0;
    virtual char* eeptpu_get_extinfo() = 0;
    virtual unsigned long eeptpu_get_memory_used_size() = 0;
    
    virtual void* eeptpu_memory_map(unsigned long addr, unsigned int len) = 0;
    virtual int eeptpu_memory_unmap(void* start, unsigned int len) = 0;
    virtual int eeptpu_mem_rd(unsigned char* buf, unsigned long addr, unsigned int len) = 0;
    virtual int eeptpu_mem_wr(unsigned char* buf, unsigned long addr, unsigned int len) = 0;
    
    virtual int eeptpu_nn_load_info(const char* path_bin) = 0;
    virtual int eeptpu_nn_load_data(unsigned long addr, unsigned int len, int flag) = 0;
    virtual int eeptpu_set_base_address(struct NET_MEM_ADDR mem_base) = 0;
    virtual int eeptpu_net_copy(EEPTPU* alg) = 0;
    virtual struct NET_MEM_SIZE eeptpu_get_memory_zone_size() = 0;
    virtual unsigned long eeptpu_get_memory_zone_addr(int flag) = 0;
    virtual unsigned int eeptpu_get_memory_zone_size(int flag) = 0;
    
public:
    int input_shape[4];
};


// Error Code
#define succ                        (0)
#define eeperr_Fail                 (-1)
#define eeperr_Param                (-2)
#define eeperr_NotSupport           (-3)
#define eeperr_FileOpen             (-4)
#define eeperr_FileRead             (-5)
#define eeperr_FileWrite            (-6)
#define eeperr_Malloc               (-7)
#define eeperr_Timeout              (-8)

#define eeperr_LoadBin              (-11)
#define eeperr_TpuInit              (-12)
#define eeperr_ImgType              (-13)
#define eeperr_PixelType            (-14)
#define eeperr_Mean                 (-15)

#define eeperr_BlobSrc              (-16)
#define eeperr_BlobFmt              (-17)
#define eeperr_BlobSize             (-18)
#define eeperr_BlobData             (-19)
#define eeperr_BlobOutput           (-20)

#define eeperr_MemAddr              (-21)
#define eeperr_MemWr                (-22)
#define eeperr_MemRd                (-23)
#define eeperr_MemMap               (-24)

#define eeperr_DevOpen              (-25)
#define eeperr_DevNotInit           (-26)
#define eeperr_InterfaceType        (-27)
#define eeperr_InterfaceInit        (-28)
#define eeperr_InterfaceOperate     (-29)

#define eeperr_EEPBinTooOld         (-40)
#define eeperr_EEPLibTooOld         (-41)
#define eeperr_TpuVerTooOld         (-42)

#endif
